Kinect Button v1.0

This is to help you get started in building Kinect applications
with buttons. It makes use of the Hoverbutton control of
the Coding4Fun Kinect toolkit.