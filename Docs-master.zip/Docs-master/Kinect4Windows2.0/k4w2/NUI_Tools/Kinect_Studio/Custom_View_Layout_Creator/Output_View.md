Output View  
===========  

The **Output View** is used primarily for activity and error logging.  



<!--Please do not edit the data in the comment block below.-->
<!--
TOCTitle : Output View
RLTitle : Output View
KeywordA : O:Microsoft.Kinect.tools.k4w_natural_input_tools_KinectStudio_outputview
KeywordA : f51bf802-7ade-37d0-8c3f-4d44a23372f9
KeywordK : Output View
KeywordK : Kinect Studio, output view
AssetID : f51bf802-7ade-37d0-8c3f-4d44a23372f9
Locale : en-us
CommunityContent : 1
TopicType : kbOrient
DocSet : K4Wv2
ProjType : K4Wv2Proj
Technology : Kinect for Windows
Product : Kinect for Windows SDK v2
productversion : 20
-->
