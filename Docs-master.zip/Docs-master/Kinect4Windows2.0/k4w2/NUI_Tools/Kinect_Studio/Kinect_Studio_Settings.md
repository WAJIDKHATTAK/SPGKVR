Kinect Studio Settings  
======================  

The Kinect Studio settings let you adjust various application settings.  

![](../../../resources/k4w_kinectstudio_settings.png)  


<!--Please do not edit the data in the comment block below.-->
<!--
TOCTitle : Kinect Studio Settings
RLTitle : Kinect Studio Settings
KeywordA : O:Microsoft.Kinect.tools.k4w_natural_input_tools_KinectStudio_settings
KeywordA : 54b75632-af56-0542-6b9d-806281f8550c
KeywordK : Kinect Studio Settings
KeywordK : Kinect Studio, settings
AssetID : 54b75632-af56-0542-6b9d-806281f8550c
Locale : en-us
CommunityContent : 1
TopicType : kbOrient
DocSet : K4Wv2
ProjType : K4Wv2Proj
Technology : Kinect for Windows
Product : Kinect for Windows SDK v2
productversion : 20
-->
