LOG View Layout  
===============  

The Log layout holds the output view and displays activity or errors.  

![](../../../resources/k4w_kinectstudio_log.png)  


<!--Please do not edit the data in the comment block below.-->
<!--
TOCTitle : LOG View Layout
RLTitle : LOG View Layout
KeywordA : O:Microsoft.Kinect.tools.k4w_natural_input_tools_KinectStudio_log
KeywordA : dc840fb5-3706-12c7-e84b-778f84922fbc
KeywordK : LOG View Layout
KeywordK : Kinect Studio, logging, output, activity, errors
AssetID : dc840fb5-3706-12c7-e84b-778f84922fbc
Locale : en-us
CommunityContent : 1
TopicType : kbOrient
DocSet : K4Wv2
ProjType : K4Wv2Proj
Technology : Kinect for Windows
Product : Kinect for Windows SDK v2
productversion : 20
-->
